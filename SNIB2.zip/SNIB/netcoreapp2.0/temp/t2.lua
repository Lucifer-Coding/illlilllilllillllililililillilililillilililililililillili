
local Byte         = string.byte;
local Char         = string.char;
local Sub          = string.sub;
local Concat       = table.concat;
local LDExp        = math.ldexp;
local GetFEnv      = getfenv or function() return _ENV end;
local Setmetatable = setmetatable;
local Select       = select;

local Unpack = unpack;
local ToNumber = tonumber;local function decompress(b)local c,d,e="","",{}local f=256;local g={}for h=0,f-1 do g[h]=Char(h)end;local i=1;local function k()local l=ToNumber(Sub(b, i,i),36)i=i+1;local m=ToNumber(Sub(b, i,i+l-1),36)i=i+l;return m end;c=Char(k())e[1]=c;while i<#b do local n=k()if g[n]then d=g[n]else d=c..Sub(c, 1,1)end;g[f]=c..Sub(d, 1,1)e[#e+1],c,f=d,d,f+1 end;return table.concat(e)end;local ByteString=decompress('2702492752232491924925D27524922723L27525V27F24921U23T22X22U25V23T27521Y23L27M27H27522I25527T25527527E27P27U24922324127P26624128026927525C28B27J24P27T24P27Q24H27T24H27V26127T26127522M25T27T25T27522A25L27T25L27522E25D27T27B24922Y26X27T26X27523226P27T26P27522Q26H27T26H27522U26927M25S28E23E1P27T1P27523I1H27T1H2752361927T27924923A1127T112751A21L27T21L28A28228E22324X28724X28028924925Z2AN21U21527M2632152AM27P25H2AN22321D28721D28027I25W27I21U22H27T22H27Q22927T22927V22127T2212B428227I2231X2871X28027P2AO2BS21U23D2AT23D27Q2352AT2352BR2AX2BS22321T28721T2AM2752AP27521U22P2AT22P2AW2492AY27622X28722X28029U24925C2CQ21U24122W27N24124824921Y23T2CW27O2CZ22I23L2D323L2CZ22M2552D32552CZ22A24X2D324X2CZ22E2CV2CX2CZ22Y24P2D324P2CZ23224H2D324H2CZ22Q2612D32612CZ22U25T2CW26325T2CZ23E25L2CW25S25L2CZ23I25D2D325D2CZ23626X2D326X2CZ23A26P2D326P2CZ1A26H2D326H2CZ1E2692D32692CZ2271P2822CQ27723S2492662492F42A425C2A421U1H2D31H2CZ2D12D323T2D52D727N2D92492DB2DD2DF192D3192DK112D3112DO21L2D321L2DT2DH27N2DJ24922Q21D2D321D2E32DQ22U2652DS24923E2152D32152EF2DV27N2DX2492362E027N2E22A52E527N2E82491A2EB27N2EE2491E2EH27N2EJ249122EM27N2EO249162ER27N2ET2491Q2EW27N2EY2491U2F122U2632F327D21L2AX2AE2841P2FA2661P2F42902CR2IA2B82D322H2FM2292D32292D52212D32212DA21T2D321T2DF23D2D323D2DK2352D32352DO22X2D322X2DT22P2D322P2DY24922Z27N24924B24922U2412JA2632412JD22725L2AX2IA2BN2I61X2CZ2232BS2672C52AN25T2AN27C24926027C2482JZ25S26V26I26L26W26V26Y27024824D27C25Z26W26S2KD24F27C25L26W26J27026V26L24824327C26026J26Y26P26O26N26W26Z26T2KD24027C26626K26O25Y26Z26R27026Y2KS2KL2752602LF2L02KD2422KV2KB26P26U26J25L26U26O2KR2482442KV26K26L26U26S26W26L26O26Y25M26O26B2KD2BS24926326W26Y26Q27226J26U26K26V27126226U26T2LR24Q24823Z27C2ME2MG2MI2MK2MM25P26J2KA26I26H2KO2KQ26Y2682482LN2752632LR27127026J2MO2MQ26J2KT2MV2NE2NG25W26U2NF2482462NM26J2NF26J2M82MA25L26O26927026T2482MC26226T26O26H26I26527026I2KC2MM2KA26L26I2K42KM26U26I26O2M526U26V2OK27525N26U2K92OP2OR2KF2752NY2KD24727C2P12MO2K726L2N22LV2KS24E27C25R26O2ON2L32KK27C25F2K62NF2F32L62752L826O2ME26I27024R2712482452LZ2M125X26U26Y26W2O82MA2482P327525X26W2682NG2NI2L42LF2LR2482PC27526426V2L22L42PW2PY2OT2OD27026L25Y26V25M2N526M2OR2Q82492PK2MM27026926327026P26W26N26O2QH2PO24925M26Y2KP2KQ2PQ2PX27C2652PF26H26T2QB25Y2NV2NG2Q727C25S27226V2LR2702PQ2K62PT2KS24C27C2672N22KJ2482S62P026L2682L42482RE25P2R526L2QA26Z2O32KE27C2SJ2692KS2JZ2672OQ26L2672MF2KD2KU2Q92LV27025T27026O27226P2KS23U27C25W26W2692PE2PG2L42662N226H26P2702KJ2OJ2JZ25N2M626P2SR2KS2T12492TU2NI2MR2NL2752TU2RG2Q42702PW2JZ2U32M92MB2SQ2SK25M2P826U26Q2702TZ26J2MS2MU2U22UD2UF2UH2N12N32N52KP2KB2N92MC2TU2UR2K72UT2N72N92QQ2TX2SK2N12ML2Q326L2LM2UC2SS25Q2TK26H2U62RV2UN2SS25D2602O82RY2KJ2LW2R12TU25C2VM2T726V2VP2PB2VC26L2ND2F32O62L42KO2TU2QV2SV26Y26K2OJ2RE25W26K26T2M525X2T32482FA27525L2RQ2KC2LQ26T2NW2UJ2MS2NT2WL2WN2R82MP2NW2TU2NS2P42LQ26M2KH2M526N2702K626H2M02RL2VJ26L2642712OO2QN2T02RW2M32722702SM2SO2SC24925S2XL2VB2752XS26W2XM2WS2X12XV2XT25N2LE2QU2732732S42LX2XK2XX2702Y32LF2P12WJ2YA2XM2UZ2N42N62UV2XC2492Y326I2KI2RP2702NP2NR2RE2U42L425P2682VG2NA2P42O82KC2622KQ2VA2NK2TW25M2Z42702YX2KD2U826O2L42P1249');

local BitXOR = bit and bit.bxor or function(a,b)
    local p,c=1,0
    while a>0 and b>0 do
        local ra,rb=a%2,b%2
        if ra~=rb then c=c+p end
        a,b,p=(a-ra)/2,(b-rb)/2,p*2
    end
    if a<b then a=b end
    while a>0 do
        local ra=a%2
        if ra>0 then c=c+p end
        a,p=(a-ra)/2,p*2
    end
    return c
end

local function gBit(Bit, Start, End)
	if End then
		local Res = (Bit / 2 ^ (Start - 1)) % 2 ^ ((End - 1) - (Start - 1) + 1);

		return Res - Res % 1;
	else
		local Plc = 2 ^ (Start - 1);

        return (Bit % (Plc + Plc) >= Plc) and 1 or 0;
	end;
end;

local Pos = 1;

local function gBits32()
    local W, X, Y, Z = Byte(ByteString, Pos, Pos + 3);

	W = BitXOR(W, 153)
	X = BitXOR(X, 153)
	Y = BitXOR(Y, 153)
	Z = BitXOR(Z, 153)

    Pos	= Pos + 4;
    return (Z*16777216) + (Y*65536) + (X*256) + W;
end;

local function gBits8()
    local F = BitXOR(Byte(ByteString, Pos, Pos), 153);
    Pos = Pos + 1;
    return F;
end;

local function gFloat()
	local Left = gBits32();
	local Right = gBits32();
	local IsNormal = 1;
	local Mantissa = (gBit(Right, 1, 20) * (2 ^ 32))
					+ Left;
	local Exponent = gBit(Right, 21, 31);
	local Sign = ((-1) ^ gBit(Right, 32));
	if (Exponent == 0) then
		if (Mantissa == 0) then
			return Sign * 0; -- +-0
		else
			Exponent = 1;
			IsNormal = 0;
		end;
	elseif (Exponent == 2047) then
        return (Mantissa == 0) and (Sign * (1 / 0)) or (Sign * (0 / 0));
	end;
	return LDExp(Sign, Exponent - 1023) * (IsNormal + (Mantissa / (2 ^ 52)));
end;

local gSizet = gBits32;
local function gString(Len)
    local Str;
    if (not Len) then
        Len = gSizet();
        if (Len == 0) then
            return '';
        end;
    end;

    Str	= Sub(ByteString, Pos, Pos + Len - 1);
    Pos = Pos + Len;

	local FStr = {}
	for Idx = 1, #Str do
		FStr[Idx] = Char(BitXOR(Byte(Sub(Str, Idx, Idx)), 153))
	end

    return Concat(FStr);
end;

local gInt = gBits32;
local function _R(...) return {...}, Select('#', ...) end

local function Deserialize()
    local Instrs = { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 };
    local Functions = {  };
	local Lines = {};
    local Chunk = 
	{
		Instrs,
		nil,
		Functions,
		nil,
		Lines
	};for Idx=1,gBits32() do 
									local Data1=BitXOR(gBits32(),210);
									local Data2=BitXOR(gBits32(),74); 

									local Type=gBit(Data1,1,2);
									local Opco=gBit(Data2,1,11);
									
									local Inst=
									{
										Opco,
										gBit(Data1,3,11),
										nil,
										nil,
										Data2
									};

									if (Type == 0) then Inst[3]=gBit(Data1,12,20);Inst[5]=gBit(Data1,21,29);
									elseif(Type==1) then Inst[3]=gBit(Data2,12,33);
									elseif(Type==2) then Inst[3]=gBit(Data2,12,32)-1048575;
									elseif(Type==3) then Inst[3]=gBit(Data2,12,32)-1048575;Inst[5]=gBit(Data1,21,29);
									end;
									
									Instrs[Idx]=Inst;end;for Idx=1,gBits32() do Functions[Idx-1]=Deserialize();end;
								local ConstCount = gBits32()
    							local Consts = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

								for Idx=1,ConstCount do 
									local Type=gBits8();
									local Cons;
	
									if(Type==2) then Cons=(gBits8() ~= 0);
									elseif(Type==3) then Cons = gFloat();
									elseif(Type==1) then Cons=gString();
									end;
									
									Consts[Idx]=Cons;
								end;
								Chunk[2] = Consts
								Chunk[4] = gBits8();return Chunk;end;
local function Wrap(Chunk, Upvalues, Env)
	local Instr  = Chunk[1];
	local Const  = Chunk[2];
	local Proto  = Chunk[3];
	local Params = Chunk[4];

	return function(...)
		local Instr  = Instr; 
		local Const  = Const; 
		local Proto  = Proto; 
		local Params = Params;

		local _R = _R
		local InstrPoint = 1;
		local Top = -1;

		local Vararg = {};
		local Args	= {...};

		local PCount = Select('#', ...) - 1;

		local Lupvals	= {};
		local Stk		= {};

		for Idx = 0, PCount do
			if (Idx >= Params) then
				Vararg[Idx - Params] = Args[Idx + 1];
			else
				Stk[Idx] = Args[Idx + 1];
			end;
		end;

		local Varargsz = PCount - Params + 1

		local Inst;
		local Enum;	

		while true do
			Inst		= Instr[InstrPoint];
			Enum		= Inst[1];if Enum <= 10 then if Enum <= 4 then if Enum <= 1 then if Enum > 0 then Stk[Inst[2]]=Const[Inst[3]];else Stk[Inst[2]][Const[Inst[3]]]=Stk[Inst[5]];end; elseif Enum <= 2 then do return end; elseif Enum == 3 then local B;local T;local A;Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];A=Inst[2];T=Stk[A];B=Inst[3];for Idx=1,B do T[Idx]=Stk[A+Idx] end;else Stk[Inst[2]]={unpack({}, 1, Inst[3])};end; elseif Enum <= 7 then if Enum <= 5 then Stk[Inst[2]]={unpack({}, 1, Inst[3])};InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]]; elseif Enum > 6 then local B;local T;local A;Stk[Inst[2]]={unpack({}, 1, Inst[3])};InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];A=Inst[2];T=Stk[A];B=Inst[3];for Idx=1,B do T[Idx]=Stk[A+Idx] end;else Stk[Inst[2]]={unpack({}, 1, Inst[3])};InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];end; elseif Enum <= 8 then Stk[Inst[2]]=Const[Inst[3]]; elseif Enum > 9 then Stk[Inst[2]]={unpack({}, 1, Inst[3])};else local A=Inst[2];local Limit=A+Inst[3]-2;local Output={};local Edx=0;for Idx=A,Limit do Edx=Edx+1;Output[Edx]=Stk[Idx];end; do return Unpack(Output,1,Edx) end;end; elseif Enum <= 16 then if Enum <= 13 then if Enum <= 11 then Stk[Inst[2]]={unpack({}, 1, Inst[3])};InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]]; elseif Enum > 12 then Stk[Inst[2]][Const[Inst[3]]]=Stk[Inst[5]];else local A=Inst[2];local Limit=A+Inst[3]-2;local Output={};local Edx=0;for Idx=A,Limit do Edx=Edx+1;Output[Edx]=Stk[Idx];end; do return Unpack(Output,1,Edx) end;end; elseif Enum <= 14 then Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]]; elseif Enum > 15 then local A=Inst[2];local T=Stk[A];local B=Inst[3];for Idx=1,B do T[Idx]=Stk[A+Idx] end;else local B;local T;local A;Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];A=Inst[2];T=Stk[A];B=Inst[3];for Idx=1,B do T[Idx]=Stk[A+Idx] end;end; elseif Enum <= 19 then if Enum <= 17 then do return end; elseif Enum == 18 then local B;local T;local A;Stk[Inst[2]]={};InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]={unpack({}, 1, Inst[3])};InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];A=Inst[2];T=Stk[A];B=Inst[3];for Idx=1,B do T[Idx]=Stk[A+Idx] end;else Stk[Inst[2]]={unpack({}, 1, Inst[3])};InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];InstrPoint = InstrPoint + 1;Inst = Instr[InstrPoint];Stk[Inst[2]]=Const[Inst[3]];end; elseif Enum <= 20 then Stk[Inst[2]]={}; elseif Enum == 21 then Stk[Inst[2]]={};else local A=Inst[2];local T=Stk[A];local B=Inst[3];for Idx=1,B do T[Idx]=Stk[A+Idx] end;end;
			InstrPoint	= InstrPoint + 1;
		end;
    end;
end;	
return Wrap(Deserialize(), {}, GetFEnv())();
